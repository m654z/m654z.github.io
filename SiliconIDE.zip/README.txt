--SiliconIDE v1--
Made by m654z

This is an IDE (sorta) for a language of mine called Silicon. This program requires the "silicon.bat" file and Silicon folder to work properly. It also requires Python 3.4. Also, please not that this is a minimal IDE, so don't expect Visual Studio-level features ;)

*How to use*

Run your code by pressing the Run button. If input is needed, a command prompt will appear. Type the input into it. The output will appear in the bottom text box.