﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kstroke2
{
    public partial class designer : Form
    {
        bool image = true;
        string info;
        public designer()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                image = false;
                txtImage.Enabled = false;
            }
            else
            {
                image = true;
                txtImage.Enabled = true;
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (image == true)
            {
                info = txtImage.Text + Environment.NewLine + txtTitle.Text + Environment.NewLine + txtInfo.Text;
            }
            else
            {
                info = "none" + Environment.NewLine + txtTitle.Text + Environment.NewLine + txtInfo.Text;
            }
            using (var save = new SaveFileDialog())
            {
                save.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                save.FilterIndex = 1;

                if (save.ShowDialog() == DialogResult.OK)
                {
                    System.IO.File.WriteAllText(save.FileName, info);
                }
            }
        }

        private void designer_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control|Keys.S))
            {
                saveToolStripMenuItem.PerformClick();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
