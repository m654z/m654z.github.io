﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace Kstroke2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Hide();
        }

        public string search(string key)
        {
            string name;
            string text = "";
            string image = "";
            string title = "";

            DirectoryInfo searchDir = new DirectoryInfo(@"pages\");
            FileInfo[] files = searchDir.GetFiles(key + "*.txt");
            Debug.Write(files.ToString());

            foreach(FileInfo results in files)
            {
                name = results.FullName;
                text = System.IO.File.ReadAllText(name);
                image = File.ReadLines(name).First();
                title = File.ReadLines(name).Skip(1).Take(1).First();
            }
            return title + "|" + image + "|" + text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string[] info = search(txtSearch.Text).Split('|');
                if (info[1] == "none")
                {
                    ;
                }
                else
                {
                    picImage.Image = Image.FromFile(@"pages\" + info[1]);
                }
                var lines = Regex.Split(info[2], "\r\n|\r|\n").Skip(2);
                string txtInfo = string.Join(Environment.NewLine, lines.ToArray());
                lblInfo.Text = txtInfo;
                lblTitle.Text = info[0];
            }
            catch
            {
                ;
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys k)
        {
            if (k == Keys.Enter)
            {
                btnSearch.PerformClick();
            }
            return base.ProcessCmdKey(ref msg, k);
        }

        private void pageDesignerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            designer designer = new Kstroke2.designer();
            designer.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
            if (!System.IO.Directory.Exists(@"pages"))
            {
                System.IO.Directory.CreateDirectory(@"pages");
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                this.TopMost = true;
            }
            else
            {
                this.TopMost = false;
            }
        }

        private void folderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(@"pages");
        }
    }
}
