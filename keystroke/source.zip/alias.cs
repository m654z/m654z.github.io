﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace Kstroke2
{
    public partial class alias : Form
    {
        string working_dir;
        string file;

        public alias(string dir)
        {
            InitializeComponent();
            working_dir = dir;
            file = @"pages\" + working_dir + @"\other\alias.txt";
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                string content = File.ReadAllText(file);
                if (content == "none")
                {
                    File.WriteAllText(file, "");
                }
                File.AppendAllText(file, txtSearch.Text + "|" + txtLink.Text + Environment.NewLine);
                txtSearch.Text = "";
                txtLink.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Something went wrong.");
                Debug.Write(ex);
                
            }
        }

        private void alias_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.S))
            {
                tsmSave.PerformClick();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
