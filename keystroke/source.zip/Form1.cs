﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace Kstroke2
{
    public partial class Form1 : Form
    {
        string working_dir = @"";
        Dictionary<string, string> aliases = new Dictionary<string, string>();

        public Form1()
        {
            InitializeComponent();
            this.Hide();
        }

        public void loader(string file)
        {
            string[] lines = System.IO.File.ReadAllLines(file);
            if (lines[0] != "loader")
            {
                MessageBox.Show(file.ToString() + " isn't a correct loader file.");
            }
            else
            {
                working_dir = lines[2];
                txtSearch.Enabled = true;
                btnSearch.Enabled = true;
                txtSearch.Text = "";
                lblLibrary.Text = "Library: " + lines[1];
                string[] alias = System.IO.File.ReadAllLines(@"pages\" + working_dir + @"\other\alias.txt");
                if (alias[0] == "none")
                {
                    ;
                }
                else
                {
                    foreach (string s in alias)
                    {
                        string[] a = s.Split('|');
                        aliases.Add(a[0], a[1]);
                    }
                }
            }
        }

        public string search(string key)
        {
            string name;
            string text = "";
            string image = "";
            string title = "";

            DirectoryInfo searchDir = new DirectoryInfo(@"pages\" + working_dir);
            FileInfo[] files = searchDir.GetFiles(key + "*.txt");
            Debug.Write(files.ToString());

            if (aliases.ContainsKey(key))
            {
                files = searchDir.GetFiles(aliases[key] + "*.txt");
            }

            foreach(FileInfo results in files)
            {
                name = results.FullName;
                text = System.IO.File.ReadAllText(name);
                image = File.ReadLines(name).First();
                title = File.ReadLines(name).Skip(1).Take(1).First();
            }
            return title + "|" + image + "|" + text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string[] info = search(txtSearch.Text).Split('|');
                if (info[1] == "none")
                {
                    ;
                }
                else
                {
                    picImage.Image = Image.FromFile(@"pages\" + working_dir + @"\" + @"images\" + info[1]);
                }
                var lines = Regex.Split(info[2], "\r\n|\r|\n").Skip(2);
                string txtInfo = string.Join(Environment.NewLine, lines.ToArray());
                lblInfo.Text = txtInfo;
                lblTitle.Text = info[0];
            }
            catch
            {
                ;
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys k)
        {
            if (k == Keys.Enter)
            {
                btnSearch.PerformClick();
            }
            return base.ProcessCmdKey(ref msg, k);
        }

        private void pageDesignerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            designer designer = new Kstroke2.designer();
            designer.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
            if (!System.IO.Directory.Exists(@"pages"))
            {
                System.IO.Directory.CreateDirectory(@"pages");
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                this.TopMost = true;
            }
            else
            {
                this.TopMost = false;
            }
        }

        private void folderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Debug.Write("Clicked");
            OpenFileDialog open = new OpenFileDialog();
            Debug.Write("OK!");
            DialogResult r = open.ShowDialog();
            if (r == DialogResult.OK)
            {
                string load = open.FileName;
                Debug.Write(load);
                loader(load);
                Debug.Write(working_dir);
            }
        }
    }
}
