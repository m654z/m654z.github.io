﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Kstroke2
{
    public partial class new_library : Form
    {
        string working_dir = @"";

        public new_library()
        {
            InitializeComponent();
        }

        private void new_library_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
        }

        private void generateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            working_dir = @"pages\" + txtFolder.Text + @"\";
            Directory.CreateDirectory(working_dir);
            Directory.CreateDirectory(working_dir + @"images");
            Directory.CreateDirectory(working_dir + @"other");
            using (File.Create(working_dir + @"other\alias.txt")) { }
            File.AppendAllLines(@"pages\" + txtName.Text + ".ks", new[] {"loader", txtName.Text, txtFolder.Text});
            MessageBox.Show("Generated library " + txtName.Text + " in " + txtFolder.Text);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.G))
            {
                generateToolStripMenuItem.PerformClick();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
